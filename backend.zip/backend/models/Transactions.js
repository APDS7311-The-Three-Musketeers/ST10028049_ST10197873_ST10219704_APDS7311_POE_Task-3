import mongoose from "mongoose";

// Define the transaction schema
const transactionSchema = new mongoose.Schema({
    accountHolderName: {
        type: String,
        required: true,
        match: [/^[a-zA-Z\s]{1,30}$/, "No special characters or numbers allowed"]
    },
    payeeAccountNumber: {
        type: String,
        required: true,
        trim: true,
        match: [/^\d{9,11}$/, "Account number must be between 9 and 11 digits"]
    },
    bankName: {
        type: String,
        required: true,
        match: [/^[a-zA-Z0-9\s,]{1,40}$/, "No special characters are allowed"]
    },
    bankAddress: {
        type: String,
        required: true,
        match: [/^[a-zA-Z0-9\s,]+$/, "No special characters are allowed"]
    },
    swiftCode: {
        type: String,
        required: true,
        match: [/^[a-zA-Z0-9\s]{8,11}$/, "Account number must be between 8 and 11 digits"]
    },
    iban: {
        type: String,
        required: false,
        match: [/^[a-zA-Z0-9\s,]{1,45}$/, "Account number must be 0 and 36 digits"]
    },
    transactionAmount: {
        type: Number,
        required: true,
        min: [0, 'Transaction amount cannot be negative'],
    },
    currency: {
        type: String,
        required: true,
        enum: ['ZAR', 'USD', 'EUR', 'GBP'],
        default: 'ZAR'
    },
    provider: {
        type: String,
        required: true,
        enum: ['SWIFT', 'PayPal', 'Stripe', 'Square', 'Apple Pay'],
        default: 'SWIFT'
    },
    transactionDate: {
        type: Date,
        required: true,
        default: Date.now,
        immutable: true
    },
    transactionStatus: {
        type: String,
        required: true,
        enum: ['Pending', 'Verified', 'SwiftSubmitted'],
        default: 'Pending'
    },
    isVerified: {
         type: Boolean, 
         default: false 
    },
    isSubmittedToSwift: { 
        type: Boolean, 
        default: false 
    },
});

export default mongoose.model("Transaction", transactionSchema);

//Reference List
/*terrance.2016.Protecting Input: Implement Whitelists,16 November 2016.[Online].Available at:https://www.interstell.com/wordpress/protecting-input-implement-whitelists/ .[Accessed 6 November 2024]*/
/*user4584103.2016.HTML5 restricting input characters, 19 May 2016.[Online].Available at: https://stackoverflow.com/questions/13607278/html5-restricting-input-characters .[Accessed 6 November 2024]*/