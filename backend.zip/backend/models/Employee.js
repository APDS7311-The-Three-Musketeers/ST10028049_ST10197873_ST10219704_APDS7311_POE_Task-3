import mongoose from "mongoose";

// Define the employee schema for the employee model
const employeeSchema = new mongoose.Schema({
    fullname:{
        type: String,
        required: true,
        match: [/^[a-zA-Z\s]{1,30}$/, "No special characters or numbers allowed"] //regex validation to allow only alphabets and 0-30 characters, adapted from (terrance.2016) and (user4584103.2016)
    },
    email: {
        type: String,  
        required: true,
        trim: true,
        unique: true,  
        match: [/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, "Invalid email address"] // Regex to validate email format, (Allan.2019)
    },
    username: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        match: [/^[a-zA-Z0-9_]+$/,"Only alphanumeric characters and underscores"] // Regex to validate username format, (Gumbo.2009).
    },
    password: {
        type: String,
        unique: true,
        required: true   
     },
     role: {  //role-based access to prottect from unauthorized access.
        type: String,
        enum: ['employee', 'user'],
        default: 'employee',
      },
      createdAt: {
        type: Date,
        default: Date.now,
      }
});

export default mongoose.model("Employee",employeeSchema);

//Reference List
/*Allan.2019.How to validate email by whitelist domain regex,8 January 2019.[Online].Available at:https://stackoverflow.com/questions/54087566/how-to-validate-email-by-whitelist-domain-regex .[Accessed 3 October 2024]*/
/*aixecador.2020. E11000 duplicate key error index in mongodb mongoose, 10 January 2020.[Online].Available at: https://stackoverflow.com/questions/24430220/e11000-duplicate-key-error-index-in-mongodb-mongoose .[Accessed 4 October 2024]*/
/*Gumbo.2009.Validate username as alphanumeric with underscores,25 August 2009.[Online]. Available at:https://stackoverflow.com/questions/1330693/validate-username-as-alphanumeric-with-underscores .[Accessed 3 October 2024] */
/*terrance.2016.Protecting Input: Implement Whitelists,16 November 2016.[Online].Available at:https://www.interstell.com/wordpress/protecting-input-implement-whitelists/ .[Accessed 6 November 2024]*/
/*user4584103.2016.HTML5 restricting input characters, 19 May 2016.[Online].Available at: https://stackoverflow.com/questions/13607278/html5-restricting-input-characters .[Accessed 6 November 2024]*/
