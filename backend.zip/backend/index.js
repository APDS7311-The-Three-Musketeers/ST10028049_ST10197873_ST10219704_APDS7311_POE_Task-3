import './config.js';
import express from 'express';
import cors from 'cors';
import https from 'https';
import fs from 'fs';
import helmet from 'helmet';
import morgan from 'morgan';
import connectDB from './db/conn.js';
import authRoutes from './Routes/auth.js';
import transactionRoutes from './Routes/transaction.js';
import employeeRoutes from './Routes/employee.js';

const app = express();
const PORT = process.env.PORT || 5000;

//connect to database
connectDB();

//Middleware
app.use(express.json());
app.use(helmet()) //add extra layer of security to your API
app.use(morgan('combined')); //Log HTTP requests
app.use(cors({ 
    origin: 'https://localhost:3000', // Only allow requests from your frontend
    methods: ['GET', 'POST','PATCH'], // Specify allowed HTTP methods
    allowedHeaders: ['Content-Type', 'Authorization'], // Specify allowed headers
    optionsSuccessStatus: 200
})); //enable cors, this method was adapted from: (Rahul. 2024)

//Routes
app.use('/api/auth',authRoutes);
app.use('/api',transactionRoutes);
app.use('/api/employee',employeeRoutes);

//SSL Certificate and key
const options = {
    key: fs.readFileSync('keys/privatekey.pem'),
    cert: fs.readFileSync('keys/certificate.pem')
}

https.createServer(options,app).listen(PORT,()=>{
    console.log(`Server is running on port ${PORT}`);
})

//Reference List
/*Meghana,D. 2024. 7 Best Practices for Securing MERN Stack Applications, 5 September 2024. [Online]. Available at:https://www.guvi.com/blog/best-practices-to-secure-mern-stack-applications/ .[Accessed 9 November 2024]*/
/*Rahul.2024. Protecting APIs in the MERN Stack: Best Practices for Securing Your Applications, 6 August 2024. [Online]. Available at: https://techtalkstrend.medium.com/protecting-apis-in-the-mern-stack-best-practices-for-securing-your-applications-cf28de0dd4aa .[Accessed 10 November 2024]*/