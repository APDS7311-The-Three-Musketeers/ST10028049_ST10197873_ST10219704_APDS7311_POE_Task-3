import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/Employee.js';
import Transaction from '../models/Transactions.js';
import bruteForce from '../middleware/bruteForceProtectionMiddleware.js';
import loginAttemptLogger from '../middleware/loginAttemptLogMiddleware.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET;

//Registration method removed to ensure that there is static login.
//The user is pre-registred in the database, therefore users cannot create an employee account.


//login for created employee accounts
router.post('/login', bruteForce.prevent, loginAttemptLogger, async (req, res) => {
  try {
    const { username, password} = req.body;

    //Find the user by username
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check the password
    const passwordisMatch = await bcrypt.compare(password, user.password);
    if (!passwordisMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    //Create a JWT token
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1h' });

    res.json({ token });

  } catch (err) {
    res.status(500).json({ message: 'Internal Server error', error: err.message});
  }
});

//retrieves all unverified transactions 
//(Chaoo Charles.2021)
router.get('/transactions', authMiddleware, async (req, res) => {
  try {
    const transactions = await Transaction.find({ isVerified: false });
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ message: 'There are no unverified transactions', error });
  }
});

//retrieves all verified transactions
//(Chaoo Charles.2021)
router.get('/verified', authMiddleware, async (req, res) => {
  try {
    const transactions = await Transaction.find({ isVerified: true });
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ message: 'There are no verified transactions', error });
  }
});

//retrieves all submit to swift transactions
router.get('/swift', authMiddleware, async (req, res) => {
  try {
    const transactions = await Transaction.find({ isSubmittedToSwift: true });

    //This method was adapted from (Natac13.2020)
    if (!transactions || transactions.length == 0) {  
        throw new Error('There are no transactions submitted to swift'); 
    }
    res.json(transactions);
  } catch (error) {
    console.error('Error Occurred:', error); // This logs the error for debugging
    res.status(500).json({ error: error.message });
  }  
});

// Verify transaction
router.patch('/verify/:id', authMiddleware, async (req, res) => { 
try {
  const { id } = req.params;
  
  // Update the transaction's verification status
  const transaction = await Transaction.findByIdAndUpdate(id, { isVerified: true }, { new: true });
  res.json(transaction);
  return res.status(200).json({ message: "Transaction is verified successfully" });
  
} catch (error) {
  res.status(500).json({ message: 'Failed to verify transaction', error });
}
});

// Submit transaction to Swift
router.patch('/submit/:id', authMiddleware, async (req, res) => {
try {
  const { id } = req.params;

  // Update the transaction's submit to swift status
  const transaction = await Transaction.findByIdAndUpdate(id, { isSubmittedToSwift: true }, { new: true });
  res.json(transaction);
  return res.status(200).json({ message: "Transaction submitted successfully" });

} catch (error) {
  res.status(500).json({ message: 'Failed to submit transaction to Swift', error });
}
});


export default router

//Reference List
/*Baxter, L. 2013. Password Regular Expression, 14 January 2013. [Online]. Available at: https://www.ocpsoft.org/tutorials/regular-expressions/password-regular-expression/ .[Accessed 6 November 2024]*/
/*Chaitanya,A. 2023.Salting and Hashing Passwords with bcrypt.js: A Comprehensive Guide, 20 June 2023. [Online]. Available at:https://medium.com/@arunchaitanya/salting-and-hashing-passwords-with-bcrypt-js-a-comprehensive-guide-f5e31de3c40c .[Accessed 4 October 2024]*/
/*Handling PATCH Requests in Node.js #11 | MERN Stack Tutorial With Auth.2021. YouTube video added by Chaoo Charles.[Online].Available at: https://www.youtube.com/watch?v=PrOza8Zo6mc .[Accessed 10 November 2024]*/
/*model and hashing password Ecommerce Mern app | Mern stack project.2023. YouTube video added by Techinfo YT.[Online].Available at: https://www.youtube.com/watch?v=vhg9IhwdVVM&list=PLuHGmgpyHfRzhGkSUfY0vpi67X64g0mXB&index=5 .[Accessed 4 October 2024]*/
/*Natac13.2020. Need help to understand transactions a little bit better, May 2020. [Online]. Available at: https://www.mongodb.com/community/forums/t/need-help-to-understand-transactions-a-little-bit-better/4308/5 .[Accessed 11 November 2024]*/
/*mdn_web docs. n.d. throw, n.d. [Online]. Available at: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/throw?form=MG0AV3 .[Accessed 11 November 2024]*/