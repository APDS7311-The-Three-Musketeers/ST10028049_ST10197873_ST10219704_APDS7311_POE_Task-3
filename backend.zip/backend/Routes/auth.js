import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import bruteForce from '../middleware/bruteForceProtectionMiddleware.js';
import loginAttemptLogger from '../middleware/loginAttemptLogMiddleware.js';
import inappropriateWordsMiddleware from '../middleware/InappropriateWordsMiddleware.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET;


//base route
router.get("/",(req,res)=>{
    res.send('Hello auth');
});

//register
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,20}$/;  //Adapted from (Baxter, L.2013)

router.post('/register', inappropriateWordsMiddleware, async (req, res) => {
    try {
        const { fullname, accountNumber, IDnumber, username, email, password: plainTextPassword } = req.body;

        // Check if the username or email already exists
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.status(400).json({ message: "Username or email already exists" });
        }

        // Validate password format before hashing
          if (!passwordRegex.test(plainTextPassword)) {
            return res.status(400).json({ message: "Invalid password format: must be 8-20 characters, with at least one uppercase letter, one lowercase letter, one number, and one special character." });
          }
        else{
        // Salting and hashing the password
        const saltRounds = 10;
        const hashedPassword = bcrypt.hashSync(plainTextPassword, saltRounds);

        // Create a new user
        const newUser = new User({ fullname, accountNumber, IDnumber, username, email, password: hashedPassword });
        await newUser.save();

        return res.status(201).json({ message: "User created successfully!" });
        }
    } catch (err) {
        res.status(500).json({ message: 'Internal Server error', error: err });
    }
});

//login
router.post('/login', bruteForce.prevent, loginAttemptLogger, async (req, res) => {
    try {
      const { username, password, accountNumber} = req.body;
  
      //Find the user by username
      const user = await User.findOne({ username });
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
  
      // Check the password
      const passwordisMatch = await bcrypt.compare(password, user.password);
      if (!passwordisMatch) {
        return res.status(400).json({ message: "Invalid credentials" });
      }

       // Check the account number
    if (accountNumber !== accountNumber) {
        return res.status(400).json({ message: "Invalid Account number" });
      }

      //Create a JWT token
      const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1h' });
  
      res.json({ token });

    } catch (err) {
      res.status(500).json({ message: 'Internal Server error', error: err.message});
    }
  });


export default router

//Reference List
/*Chaitanya,A. 2023.Salting and Hashing Passwords with bcrypt.js: A Comprehensive Guide, 20 June 2023. [Online]. Available at:https://medium.com/@arunchaitanya/salting-and-hashing-passwords-with-bcrypt-js-a-comprehensive-guide-f5e31de3c40c .[Accessed 4 October 2024]*/
/*model and hashing password Ecommerce Mern app | Mern stack project.2023. YouTube video added by Techinfo YT.[Online].Available at: https://www.youtube.com/watch?v=vhg9IhwdVVM&list=PLuHGmgpyHfRzhGkSUfY0vpi67X64g0mXB&index=5 .[Accessed 4 October 2024]*/
/*Baxter, L. 2013. Password Regular Expression, 14 January 2013. [Online]. Available at: https://www.ocpsoft.org/tutorials/regular-expressions/password-regular-expression/ .[Accessed 6 November 2024]*/