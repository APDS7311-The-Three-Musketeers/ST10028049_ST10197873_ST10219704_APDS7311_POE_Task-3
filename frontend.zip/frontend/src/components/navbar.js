import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
    const [userRole, setUserRole] = useState(null); // State to track the user role
    const navigate = useNavigate();

    // Function to check user role from local storage
    const checkUserRole = () => {
        if (localStorage.getItem('token')) {
            setUserRole('customer');
        } else if (localStorage.getItem('employeeToken')) {
            setUserRole('employee');
        } else {
            setUserRole(null);
        }
    };

    useEffect(() => {
        // Check the user role on initial render
        checkUserRole();

        // Add an event listener to listen for login status changes
        window.addEventListener('userRoleUpdated', checkUserRole);

        // Clean up the event listener on component unmount
        return () => {
            window.removeEventListener('userRoleUpdated', checkUserRole);
        };
    }, []);

    // Log off function
    const handleLogOff = () => {
        // Clear tokens from local storage
        localStorage.removeItem('token');
        localStorage.removeItem('employeeToken');
        setUserRole(null);
        navigate('/'); // Navigate back to the main page
    };

    return (
        <nav className="navbar">
            <div className="navbar-container">
                <NavLink to="/" className="navbar-logo">Home</NavLink>
                <ul className="navbar-menu">
                    {/* Default Links */}
                    {userRole === null && (
                        <>
                            <li className="navbar-item">
                                <NavLink to="/register" className="navbar-link" activeClassName="active">Customer Registration</NavLink>
                            </li>
                            <li className="navbar-item">
                                <NavLink to="/login" className="navbar-link" activeClassName="active">Customer Login</NavLink>
                            </li>
                            <li className="navbar-item">
                                <NavLink to="/employeelogin" className="navbar-link" activeClassName="active">Employee Login</NavLink>
                            </li>
                        </>
                    )}

                    {/* Customer-specific Links */}
                    {userRole === 'customer' && (
                        <li className="navbar-item">
                            <NavLink to="/transactions" className="navbar-link" activeClassName="active">Transactions</NavLink>
                        </li>
                    )}

                    {/* Employee-specific Links */}
                    {userRole === 'employee' && (
                        <li className="navbar-item">
                            <NavLink to="/verifytransactions" className="navbar-link" activeClassName="active">Transaction Verification</NavLink>
                        </li>
                    )}

                    {/* Log Off Link */}
                    {userRole && (
                        <li className="navbar-item">
                            <button onClick={handleLogOff} className="navbar-link logoff-button">Log Off</button>
                        </li>
                    )}
                </ul>
            </div>
        </nav>
    );
}

export default Navbar;

// References: 
// Vidura Senevirathne (2024). Creating a Navbar in React — SitePoint. [online] Sitepoint.com. Available at: https://www.sitepoint.com/creating-a-navbar-in-react/ [Accessed 11 Nov. 2024].
// M. Erim Tuzcuoglu (2021). How to show different Navbars based on authentication status and role? [online] Stack Overflow. Available at: https://stackoverflow.com/questions/68535247/how-to-show-different-navbars-based-on-authentication-status-and-role [Accessed 11 Nov. 2024].