import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './TransactionVerification.css';

function TransactionVerification() {
    const [transactions, setTransactions] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        // Fetch transactions from API
        const fetchTransactions = async () => {
            try {
                const response = await axios.get('/api/employee/transactions');
                setTransactions(response.data);
            } catch (err) {
                console.error('Failed to fetch transactions', err);
                setError('Failed to fetch transactions.');
            }
        };
    
        fetchTransactions();
    }, []);

    // Function to handle Verify button
    const handleVerify = (transactionId) => {
        setTransactions((prevTransactions) =>
            prevTransactions.map((transaction) => {
                if (transaction._id === transactionId) {
                    const isVerified = transaction.transactionStatus === 'Verified';
                    return {
                        ...transaction,
                        transactionStatus: isVerified ? 'Pending' : 'Verified',
                        isUndo: !isVerified, // Flag to toggle undo state
                    };
                }
                return transaction;
            })
        );
    };

    // Function to handle Submit to SWIFT button
    const handleSubmitToSWIFT = (transactionId) => {
        setTransactions((prevTransactions) =>
            prevTransactions.map((transaction) => {
                if (transaction._id === transactionId) {
                    return {
                        ...transaction,
                        transactionStatus: 'Submitted to SWIFT',
                        isGreyedOut: true, // Flag to disable buttons
                    };
                }
                return transaction;
            })
        );
    };

    // Separate transactions into two categories
    const allTransactions = transactions.filter(
        (transaction) => transaction.transactionStatus !== 'Submitted to SWIFT'
    );
    const submittedTransactions = transactions.filter(
        (transaction) => transaction.transactionStatus === 'Submitted to SWIFT'
    );

    return (
        <div className="transactions-container">
            <h1>Transaction Verification</h1>
            {error && <p className="error-message">{error}</p>}

            {/* Table for All Transactions */}
            <h2>All Transactions</h2>
            <table className="transactions-table">
                <thead>
                    <tr>
                        <th>Account Holder</th>
                        <th>Payee Account Number</th>
                        <th>Bank Name</th>
                        <th>Bank Address</th>
                        <th>SWIFT Code</th>
                        <th>Amount</th>
                        <th>Currency</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {allTransactions.length > 0 ? (
                        allTransactions.map((transaction) => (
                            <tr key={transaction._id}>
                                <td>{transaction.accountHolderName}</td>
                                <td>{transaction.payerAccountNumber}</td>
                                <td>{transaction.bankName}</td>
                                <td>{transaction.bankAddress}</td>
                                <td>{transaction.swiftCode}</td>
                                <td>{transaction.transactionAmount}</td>
                                <td>{transaction.currency}</td>
                                <td>{new Date(transaction.transactionDate).toLocaleDateString()}</td>
                                <td>{transaction.transactionStatus || 'Pending'}</td>
                                <td className="action-buttons">
                                    <button
                                        onClick={() => handleVerify(transaction._id)}
                                        className={transaction.isUndo ? 'undo-button' : 'verify-button'}
                                        style={{ backgroundColor: transaction.isUndo ? 'red' : 'green' }}
                                    >
                                        {transaction.isUndo ? 'Undo' : 'Verify'}
                                    </button>
                                    <button
                                        onClick={() => handleSubmitToSWIFT(transaction._id)}
                                        className="submit-button"
                                        disabled={transaction.transactionStatus !== 'Verified' || transaction.isGreyedOut}
                                    >
                                        Submit to SWIFT
                                    </button>
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="10">Loading...</td>
                        </tr>
                    )}
                </tbody>
            </table>

            {/* Table for Submitted to SWIFT Transactions */}
            <h2>Submitted to SWIFT</h2>
            <table className="transactions-table">
                <thead>
                    <tr>
                        <th>Account Holder</th>
                        <th>Payee Account Number</th>
                        <th>Bank Name</th>
                        <th>Bank Address</th>
                        <th>SWIFT Code</th>
                        <th>Amount</th>
                        <th>Currency</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {submittedTransactions.length > 0 ? (
                        submittedTransactions.map((transaction) => (
                            <tr key={transaction._id}>
                                <td>{transaction.accountHolderName}</td>
                                <td>{transaction.payerAccountNumber}</td>
                                <td>{transaction.bankName}</td>
                                <td>{transaction.bankAddress}</td>
                                <td>{transaction.swiftCode}</td>
                                <td>{transaction.transactionAmount}</td>
                                <td>{transaction.currency}</td>
                                <td>{new Date(transaction.transactionDate).toLocaleDateString()}</td>
                                <td>{transaction.transactionStatus}</td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="9">No transactions submitted to SWIFT yet.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}

export default TransactionVerification;

// References: 
// Frontend Mentor. (2024). Frontend Mentor | Integrating with APIs: A beginner’s guide for front-end developers. [online] Available at: https://www.frontendmentor.io/articles/integrating-with-apis-a-beginners-guide-for-frontend-developers-u_xfEadBc- [Accessed 11 Nov. 2024].
// Chatgpt.com. (2024). ChatGPT. [online] Available at: https://chatgpt.com/ [Accessed 11 Nov. 2024].