import React, {useEffect, useState} from 'react';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import './GetTransactions.css'; // Import CSS for styling

function GetTransactions() {
    const [transactions, setTransactions] = useState([]); 
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchTransactions = async () => {
            try {
                const token = localStorage.getItem('token');
                const response = await axios.get('/api', {
                    headers: {
                        Authorization:  `Bearer ${token}`
                    }
                });
                setTransactions(response.data);
            } catch (err) {
                setError('You are not authorized to view the transactions');
            }
        };
        fetchTransactions();
    }, []);

    return (
        <div className="transactions-container">
            <h1>Transactions</h1>
            <NavLink className="create-transaction-link" to="/create">Create Transaction</NavLink>
            
            {error ? (
                <p style={{color: 'red'}}>{error}</p>
            ) : transactions.length > 0 ? (
                <table className="transaction-table">
                    <thead>
                        <tr>
                            <th>Account Holder</th>
                            <th>Payee Account Number</th>
                            <th>Bank Name</th>
                            <th>Bank Address</th>
                            <th>Swift Code</th>
                            <th>IBAN</th>
                            <th>Amount</th>
                            <th>Currency</th>
                            <th>Provider</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {transactions.map((transaction) => (
                            <tr key={transaction._id}>
                                <td>{transaction.accountHolderName}</td>
                                <td>{transaction.payerAccountNumber}</td>
                                <td>{transaction.bankName}</td>
                                <td>{transaction.bankAddress}</td>
                                <td>{transaction.swiftCode}</td>
                                <td>{transaction.iban}</td>
                                <td>{transaction.transactionAmount}</td>
                                <td>{transaction.currency}</td>
                                <td>{transaction.provider}</td>
                                <td>{new Date(transaction.transactionDate).toLocaleDateString()}</td>
                                <td>{transaction.transactionStatus}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p>Loading...</p>
            )}
        </div>
    );
}

export default GetTransactions;