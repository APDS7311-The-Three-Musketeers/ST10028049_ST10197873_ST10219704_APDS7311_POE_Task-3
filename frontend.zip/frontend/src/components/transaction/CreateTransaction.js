import React, {useState} from "react";
import axios from "axios";
import {useNavigate} from "react-router-dom";
import './CreateTransaction.css'; // Add this line to import your CSS

const providers = [
    "SWIFT", 
    "PayPal", 
    "Stripe", 
    "Square", 
    "Apple Pay"
];

const currencies = [
    "ZAR", 
    "USD", 
    "EUR", 
    "GBP"
];

function CreateTransaction() {
    const [accountHolderName, setAccountHolderName] = useState('');
    const [bankName, setBankName] = useState('');
    const [bankAddress, setBankAddress] = useState('');
    const [swiftCode, setSwiftCode] = useState('');
    const [iban, setIban] = useState('');
    const [transactionAmount, setTransactionAmount] = useState('');
    const [selectedCurrency, setSelectedCurrency] = useState(currencies[0]);
    const [selectedProvider, setSelectedProvider] = useState(providers[0]);
    const [payerAccountNumber, setPayerAccountNumber] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem("token");
            await axios.post("/api", {
                accountHolderName, 
                bankName, 
                bankAddress, 
                swiftCode, 
                iban,
                transactionAmount,
                currency: selectedCurrency,
                provider: selectedProvider, 
                payerAccountNumber
            }, {
                headers: {
                    Authorization:  `Bearer ${token}`
                }
            });
            setAccountHolderName("");
            setBankName("");
            setBankAddress("");
            setSwiftCode("");
            setIban("");
            setTransactionAmount("");
            setSelectedCurrency(currencies[0]);
            setSelectedProvider(providers[0]);
            setPayerAccountNumber("");
            setError("");
            navigate("/transactions");
        } catch (error) {
            setError("Error making transaction");
        }
    };

    return (
        <div className="transaction-container">
            <h1 className="transaction-title">Create Transaction</h1>
            {error && <p className="transaction-error">{error}</p>}
            <form className="transaction-form" onSubmit={handleSubmit}>

                <label htmlFor="accountHolderName">Account Holder Name:</label> 
                <input type='text' id='accountHolderName' value={accountHolderName} onChange={(e) => setAccountHolderName(e.target.value)} required/>

                <label htmlFor="bankName">Bank Name:</label> 
                <input type='text' id='bankName' value={bankName} onChange={(e) => setBankName(e.target.value)} required/>

                <label htmlFor="bankAddress">Bank Address:</label> 
                <input type='text' id='bankAddress' value={bankAddress} onChange={(e) => setBankAddress(e.target.value)} required/>

                <label htmlFor="swiftCode">Swift Code:</label> 
                <input type='text' id='swiftCode' value={swiftCode} onChange={(e) => setSwiftCode(e.target.value)} required/>

                <label htmlFor="iban">IBAN:</label> 
                <input type='text' id='iban' value={iban} onChange={(e) => setIban(e.target.value)}/>

                <label htmlFor="transactionAmount">Transaction Amount:</label>  
                <input type='text' id='transactionAmount' value={transactionAmount} onChange={(e) => setTransactionAmount(e.target.value)} required/>

                <div>
                    <label htmlFor="currency">Currency</label>
                    <select id="currency" value={selectedCurrency} onChange={e => setSelectedCurrency(e.target.value)}>
                        {currencies.map(currency => (
                            <option key={currency} value={currency}>
                                {currency}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label htmlFor="provider">Provider</label>
                    <select id="provider" value={selectedProvider} onChange={e => setSelectedProvider(e.target.value)}>
                        {providers.map(provider => (
                            <option key={provider} value={provider}>
                                {provider}
                            </option>
                        ))}
                    </select>
                </div>

                <label htmlFor="payerAccountNumber">Payer Account Number:</label>  
                <input type='text' id='payerAccountNumber' value={payerAccountNumber} onChange={(e) => setPayerAccountNumber(e.target.value)} required/>

                <button className="transaction-button" type='submit'>Make Transaction</button>
            </form>
        </div>
    );
}

export default CreateTransaction;