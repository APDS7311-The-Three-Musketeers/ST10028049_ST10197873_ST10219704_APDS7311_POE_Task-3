import React, {useState} from 'react';

function ProtectedPage() {
    return (
        <h1>Protected Page</h1>  
    );
}

export default ProtectedPage;