import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Register.css'; // Import the new CSS file for styling

function Register() {
    // State variables for form inputs
    const [fullname, setFullname] = useState('');
    const [IDnumber, setIDnumber] = useState('');
    const [email, setEmail] = useState('');
    const [accountNumber, setAccountNumber] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    
    const navigate = useNavigate();

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        try {
            // Send registration data to the server
            const response = await axios.post('/api/auth/register', {
                fullname, accountNumber, IDnumber, username, email, password
            });

            // On successful registration, navigate to home page
            if (response.status === 201) {
                navigate('/');
            }
        } catch (err) {
            // Handle errors
            if (err.response) {
                setError(err.response.data.message);
            } else {
                setError('Something went wrong. Please try again.');
            }
        }
    }

    return (
        <div className="register-container">
            <h1 className="register-title">Create an Account</h1>

            {/* Registration Form */}
            <form className="register-form" onSubmit={handleSubmit}>

                {/* Full Name Input */}
                <label htmlFor="fullname">Full Name:</label>
                <input
                    type="text"
                    id="fullname"
                    name="fullname"
                    value={fullname}
                    onChange={(e) => setFullname(e.target.value)}
                    required
                    placeholder="Enter your full name"
                />

                {/* ID Number Input */}
                <label htmlFor="IDnumber">ID Number:</label>
                <input
                    type="text"
                    id="IDnumber"
                    name="IDnumber"
                    value={IDnumber}
                    onChange={(e) => setIDnumber(e.target.value)}
                    required
                    placeholder="Enter your ID number"
                />

                {/* Email Input */}
                <label htmlFor="email">Email:</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="Enter your email"
                />

                {/* Account Number Input */}
                <label htmlFor="accountNumber">Account Number:</label>
                <input
                    type="text"
                    id="accountNumber"
                    name="accountNumber"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    required
                    placeholder="Enter your account number"
                />

                {/* Username Input */}
                <label htmlFor="username">Username:</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    placeholder="Choose a username"
                />

                {/* Password Input */}
                <label htmlFor="password">Password:</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    placeholder="Create a password"
                />

                {/* Error message */}
                {error && <p className="error-message">{error}</p>}

                {/* Submit button */}
                <button type="submit" className="register-button">Register</button>
            </form>
        </div>
    );
}

export default Register;
