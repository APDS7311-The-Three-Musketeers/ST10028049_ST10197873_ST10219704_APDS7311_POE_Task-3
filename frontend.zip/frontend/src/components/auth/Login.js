import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Login.css';

function Login() {
    const [accountNumber, setAccountNumber] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        try {
            const response = await axios.post('/api/auth/login', { username, password, accountNumber });
            // Save the token to local storage
            localStorage.setItem('token', response.data.token);

            // Dispatch a custom event to notify other components
            window.dispatchEvent(new Event('userRoleUpdated'));

            // Navigate to the transactions page
            navigate('/transactions');
        } catch (err) {
            if (err.response) {
                setError(err.response.data.message);
            } else {
                setError('Something went wrong. Please try again.');
            }
        }
    };

    return (
        <div className="login-container">
            <div className="login-box">
                <h1>Login</h1>
                <form onSubmit={handleSubmit} className="login-form">
                    <label htmlFor="accountNumber">Account Number:</label>
                    <input 
                        type="text" 
                        id="accountNumber" 
                        name="accountNumber" 
                        value={accountNumber} 
                        onChange={(e) => setAccountNumber(e.target.value)} 
                        autoComplete="true" 
                        placeholder="Enter your account number"
                    />

                    <label htmlFor="username">Username:</label>
                    <input 
                        type="text" 
                        id="username" 
                        name="username" 
                        value={username} 
                        onChange={(e) => setUsername(e.target.value)} 
                        autoComplete="true" 
                        placeholder="Enter your username"
                    />

                    <label htmlFor="password">Password:</label>
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        value={password} 
                        onChange={(e) => setPassword(e.target.value)} 
                        placeholder="Enter your password"
                    />

                    {error && <p className="error-message">{error}</p>}

                    <button type="submit" className="login-button">Login</button>
                </form>
                <div className="login-footer">
                    <p>Forgot your password? <a href="/reset">Click here to reset it</a></p>
                </div>
            </div>
        </div>
    );
}

export default Login;