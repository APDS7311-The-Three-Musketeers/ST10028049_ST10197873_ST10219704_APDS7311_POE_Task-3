import React from 'react';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Navbar from './components/navbar';
import './App.css';
import ProtectedPage from './components/ProtectedPage';
import GetTransactions from './components/transaction/GetTransactions';
import CreateTransaction from './components/transaction/CreateTransaction';
import EmployeeLogin from './components/auth/EmployeeLogin'; // Import EmployeeLogin
import TransactionVerification from './components/transaction/TransactionVerification'; // Import TransactionVerification

function App() {
  return (
    <Router>
      <div className='App'>
        <Navbar/>
        <Routes>
          <Route path="/" element={<Login />}/>
          <Route path="/login" element={<Login />}/>
          <Route path="/register" element={<Register />}/>
          <Route path="/transactions" element={<GetTransactions />}/>
          <Route path="/create" element={<CreateTransaction />}/>
          <Route path="/protected" element={<ProtectedPage />}/>
          <Route path="/employeelogin" element={<EmployeeLogin />} />
          <Route path="/verifytransactions" element={<TransactionVerification />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;